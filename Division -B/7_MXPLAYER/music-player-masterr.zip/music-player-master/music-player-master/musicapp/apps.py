from django.apps import AppConfig


class MusicappConfig(AppConfig):
    name = 'musicapp'
